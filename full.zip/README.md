[![Netlify Status](https://api.netlify.com/api/v1/badges/81a8d94f-7eae-4e47-bea4-5f535fc0f9ac/deploy-status)](https://app.netlify.com/sites/amazing-douhua-d99576/deploys)

# 🚀 Innovation Club Voting Website

A sleek, secure, and interactive voting platform designed for the **Innovation Club, DPS Newtown**. Built using modern web technologies, this static-site solution supports club-wide voting, member management, and live announcements with backend integration via Google Sheets and Make (Integromat).

---

## 🔧 Features

- 🎨 **Custom Design**  
  Neon purple-pink theme inspired by the club’s branding, fully responsive.

- 🗳️ **Voting System**  
  Secure voting form with:
  - Auto-filled user data from query parameters
  - Single or multiple vote support
  - Form submission via Make webhook to Google Sheets

- 🛠️ **Admin Panel**  
  Password-protected dashboard with:
  - GitHub edit links for all pages
  - Page previews and structured table layout
  - Access to announcement and question control

- 📰 **Announcements**  
  Markdown-supported announcements loaded from `announcement.json`  
  - Scrollable, styled sidebar  
  - Live update via compose form (Make integration)

- ➕ **Add Member Portal**  
  Password-locked form to add new members  
  - Sends data to Sheets via Make  
  - Password secured using `questions.json`

- 🔐 **Authentication**  
  - Global login/logout support
  - Session persistence via localStorage
  - Admin and user roles handled simply

- 💾 **Google Sheets Integration**  
  - Members, voting config, and announcements handled from Sheets  
  - Editable via Google/GitHub UI or Make scenario

---

## 🧱 Tech Stack

- **Frontend**: HTML, CSS, JavaScript  
- **Static Hosting**: [Netlify](https://netlify.app)  
- **Backend/Automation**: Google Sheets + [Make.com](https://www.make.com)  
- **Markdown Parser**: [Marked.js](https://marked.js.org)  
- **Deployment Repo**: [GitHub Repository](https://github.com/InnovationClubDPSN/incvoting)

---

## 📁 File Structure

.
├── index.html # Main voting page
├── vote.html # Voting form page
├── addmember.html # Member addition page (password-locked)
├── admin.html # Admin panel
├── compose.html # Announcement submission
├── questions.json # Stores question, session, and password
├── announcement.json # Live announcements (markdown-supported)
├── style.css # Custom theme stylesheet
├── script.js # Global interactivity script
├── logo.png # Club logo (used in favicon + watermark)
└── README.md

---

## 🔑 Admin Access

To access admin-level features:
- Go to `admin.html`
- Enter the admin password (set in `questions.json`)

---

## 🌐 Live Deployment

📍 [https://innovationclubvotingwebsite.netlify.app](https://innovationclubvotingwebsite.netlify.app)

---

## 👨‍💻 Authors

- **Satyaki Bandopadhyay**
- **Satvik Roy**
- **Ridit Jana**  
- **Aryaman Ghosh**

---

## 📌 License

This project is for educational and club-related purposes only.
